package com.example.rameshnayak.farmerease;

/**
 * Created by Ramesh Nayak on 22-Oct-18.
 */

public class NewfeedModel {

    public String desc;
    public String image;
    public String title;

    public NewfeedModel(){

    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}





